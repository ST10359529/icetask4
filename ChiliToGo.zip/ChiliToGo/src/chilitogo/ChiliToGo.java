/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chilitogo;

/**
 *
 * @author hiran
 */
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ChiliToGo {

    /**
     * @param args the command line arguments
     */
 
    public static void main(String[] args) {
        // TODO code application logic here 
        Scanner scanner = new Scanner(System.in);

        Menu.displayMenu();

        String aMeals = JOptionPane.showInputDialog(null, "Enter number of adult meals: ");
        int adultMeals = Integer.parseInt(aMeals);
        String cMeals = JOptionPane.showInputDialog(null, "Enter number of child meals: ");
        int childMeals = Integer.parseInt(cMeals);

        MealOrder mealOrder = new MealOrder();
        mealOrder.setAdultMeals(adultMeals);
        mealOrder.setChildMeals(childMeals);

        OrderCalculator calculator = new OrderCalculator(mealOrder);
        double subtotal = calculator.calculateSubtotal();
        double tax = calculator.calculateTax(subtotal);
        double total = calculator.calculateTotal(subtotal, tax);

        System.out.println("\nOrder Summary:");
        System.out.println("Subtotal: $" + subtotal);
        System.out.println("Tax: $" + tax);
        System.out.println("Total: $" + total);
        
        PaymentMethod pay = new PaymentMethod();
        pay.selectPaymentMethod();

        scanner.close();

    }
    
}
