/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chilitogo;
/**
 *
 * @author hiran
 */
public class OrderCalculator {
    private final double ADULT_PRICE = 7.0;
    private final double CHILD_PRICE = 4.0;
    private final double TAX_RATE = 0.1;
    private final int DISCOUNT_THRESHOLD = 10;
    private MealOrder mealOrder;

    public OrderCalculator(MealOrder mealOrder) {
        this.mealOrder = mealOrder;
    }

    public double calculateSubtotal() {
        return mealOrder.getAdultMeals() * ADULT_PRICE + mealOrder.getChildMeals() * CHILD_PRICE;
    }

    public double calculateTax(double subtotal) {
        return subtotal * TAX_RATE;
    }

    public double calculateTotal(double subtotal, double tax) {
        double total = subtotal + tax;
        if (mealOrder.getAdultMeals() + mealOrder.getChildMeals() > DISCOUNT_THRESHOLD) {
            total *= 0.9; // Apply 10% discount
        }
        return total;
    }
}
