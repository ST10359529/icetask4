/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chilitogo;

/**
 *
 * @author hiran
 */
public class Menu {
    public static void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Adult Meal - $7");
        System.out.println("2. Child Meal - $4");
    }
}
