/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chilitogo;

import javax.swing.JOptionPane;

/**
 *
 * @author hiran
 */
public class MealOrder {
    private int adultMeals;
    private int childMeals;

    public MealOrder() {
        this.adultMeals = 0;
        this.childMeals = 0;
    }

    public void setAdultMeals(int adultMeals) {
        if (adultMeals >= 0) {
            this.adultMeals = adultMeals;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid input. Adult meals must be a non-negative integer."); 
        }
    }

    public void setChildMeals(int childMeals) {
        if (childMeals >= 0) {
            this.childMeals = childMeals;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid input. Child meals must be a non-negative integer.");
        }
    }

    public int getAdultMeals() {
        return adultMeals;
    }

    public int getChildMeals() {
        return childMeals;
    }
}
