/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chilitogo;

/** 
 *
 * @author hiran
 */
import javax.swing.JOptionPane;

public class PaymentMethod {
    public void selectPaymentMethod() {
        JOptionPane.showInputDialog(null, "Please select payment method: Cash, Credit Card, Debit Card, EFT.");
    }
}
